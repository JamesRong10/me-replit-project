n, m = map(int, input().split())
maze = []
for i in range(n):
    maze.append(list(input()))
move_sequence = input()
start_row, start_col = 0, 0
for row in range(n):
    for col in range(m):
        if maze[row][col] == 'S':
            start_row = row
            start_col = col
            break
current_row = start_row
current_col = start_col
for move in move_sequence:
    if move == 'u':
        current_row -= 1
    elif move == 'd':
        current_row += 1
    elif move == 'l':
        current_col -= 1
    elif move == 'r':
        current_col += 1
    if current_row < 0 or current_row >= n or current_col < 0 or current_col >= m:
        print("Oh no... I'm left in the darkness!")
        break
    if maze[current_row][current_col] == '#':
        print("Oops... I hit the wall!")
        break
    if maze[current_row][current_col] == 'E':
        print("Yay... I found the way!")
        break
else:
    print("Oh no... I'm lost!")